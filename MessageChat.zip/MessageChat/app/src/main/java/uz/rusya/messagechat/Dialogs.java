package uz.rusya.messagechat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Switch;
import android.widget.TextView;

public class Dialogs extends AppCompatActivity {

    private TextView text;
    private String currentUserId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dialogs);
        Intent intent = getIntent();
        currentUserId = intent.getStringExtra("currentUseId");

        text = findViewById(R.id.id_text);
        text.setText(currentUserId);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.action_addContact: //
                Intent intent = new Intent(Dialogs.this, CreateContactActivity.class);
                intent.putExtra("currentUseId", currentUserId);
                startActivity(intent);
                return true;
            case R.id.contactList:
                Intent intent2 = new Intent(Dialogs.this,ContactsActivity.class);
                intent2.putExtra("currentUseId", currentUserId);
                startActivity(intent2);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }


    }
}
