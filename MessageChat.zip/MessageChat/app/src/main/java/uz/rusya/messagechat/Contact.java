package uz.rusya.messagechat;


public class Contact extends User {


}
