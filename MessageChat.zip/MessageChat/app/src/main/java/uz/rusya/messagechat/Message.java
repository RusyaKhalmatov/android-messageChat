package uz.rusya.messagechat;

import java.util.HashMap;
import java.util.Map;

public class Message {

    private String authorID;
    private String messageID;
    private String chatID;
    private String content;
    private String dateCreated;


    public Message() {
    }

    public Message(String authorID, String messageID,
                   String chatID, String content, String dateCreated) {
        this.authorID = authorID;
        this.messageID = messageID;
        this.chatID = chatID;
        this.content = content;
        this.dateCreated = dateCreated;
    }

    public Map<String,Object> toMap(){
        HashMap<String,Object> result = new HashMap<>();
        result.put("authorID", authorID);
        result.put("messageID", messageID);
        result.put("chatID",chatID);
        result.put("content",content);
        result.put("dateCreated",dateCreated);

        return result;
    }
}
